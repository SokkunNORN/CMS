
<?php

register_nav_menus(
    array (
        'primary' => __('primary menu'),
        'footer' => __('footer menu')
    )
);

function themes_resource() {

}






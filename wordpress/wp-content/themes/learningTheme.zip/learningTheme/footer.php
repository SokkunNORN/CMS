
    <footer class="site-footer">
        <!-- <nav class="site-footer"> -->
            <?php //$agrs = array('theme_location'=>'footer')?>
            <small><?php //wp_nav_menu($agrs); ?></small>
        <!-- </nav> -->
        <p class="text-center">
            <?php bloginfo('name')?>-&copy; <?php echo date('Y');?>
        </p>
    </footer>
</div>
    <!-- end of container div -->
    <?php wp_footer(); ?>
    
</body>
</html>